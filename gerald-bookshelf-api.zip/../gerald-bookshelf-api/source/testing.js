books = [];

const newBook = {
    name, year, author, summary, publisher,
    pageCount, readPage, finished, reading, insertedAt, updatedAt,
};

// masukkan ke dalam array books
books.push(newBook);
